﻿//PROG1224
//Lab 5 Exercise
// Umar Kamalitdinov
using Lab5.BusinessLogic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace Lab5
{
    public sealed partial class MainPage : Page
    {
        //declare BankAccount fields
        private BankAccount[] accounts = new BankAccount[12];
        private BankAccount current;

        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
            // Populate ComboBox
            CreateAccounts(accounts);
            DisplayAccounts();
        }

        // Event Handler Methods
        private void Select_Account(object sender, SelectionChangedEventArgs e)
        {
            // This event is triggered when the selection in the combo box changes
            Display();
        }
        private void Deposit_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                // Assign SelectedIndex of ComboBox to BankAccount field
                current = accounts[cboAccount.SelectedIndex];
                decimal deposit = decimal.Parse(txtAmount.Text);
                deposit = current.Deposit(deposit);
                txtOutput.Text += $"\n\nAmount Deposited: {deposit.ToString("c2")}"
                    + $"\nNew Balance: {current.Balance}";
            }
            catch(Exception ex)
            {
                txtOutput.Text = "ERROR!!\n" + ex.Message;
            }
        }
        private void Withdraw_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Assign SelectedIndex of ComboBox to BankAccount field
                current = accounts[cboAccount.SelectedIndex];
                decimal withdraw = decimal.Parse(txtAmount.Text);
                withdraw = current.Withdraw(withdraw);
                txtOutput.Text += $"\n\nAmount Withdrawn: {withdraw.ToString("c2")}"
                    + $"\nNew Balance: {current.Balance}";
            }
            catch (Exception ex)
            {
                txtOutput.Text = "ERROR!!\n" + ex.Message;
            }
        }
        private void Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Assign SelectedIndex of ComboBox to BankAccount field
                int index = cboAccount.SelectedIndex;
                current = accounts[index];
                // Update the User Name
                current.ClientName = txtName.Text;
                // determine the exact account type to properly access the other textbox(s)
                if (current is PremiumAccount) // start with the most specific class first
                {
                    // Unbox (type-cast) the general BankAccount type to the more specific PremiumAccount
                    PremiumAccount account = (PremiumAccount)current;
                    // Work with Monthly Fee
                    string input = txtRateFee.Text.Replace('$', ' ').Trim();
                    decimal temp = decimal.Parse(input);
                    account.Fee = temp; // updating the Monthly Fee
                    txtRateFee.Text = account.Fee.ToString("c2");
                    // Work with Overdraft
                    input = txtOverDraft.Text.Replace('$', ' ').Trim();
                    temp = decimal.Parse(input);
                    account.OverDraft = temp; // updating the Overdraft Amount
                    txtOverDraft.Text = account.OverDraft.ToString("c2");
                }
                else if (current is ChequingAccount)
                {
                    ChequingAccount account = (ChequingAccount)current;
                    // Work with Monthly Fee
                    string input = txtRateFee.Text.Replace('$', ' ').Trim();
                    decimal temp = decimal.Parse(input);
                    account.Fee = temp; // updating the Monthly Fee
                    txtRateFee.Text = account.Fee.ToString("c2");
                }
                else // current is SavingsAccount
                {
                    SavingsAccount account = (SavingsAccount)current;
                    string input = txtRateFee.Text.Replace('%', ' ').Trim();
                    decimal temp = decimal.Parse(input);
                    account.Interest = temp/100M; // updating the Monthly Interest
                    txtRateFee.Text = account.Interest.ToString("p2");
                }
                Display(); // updates the output textbox
                DisplayAccounts(); // update the combo box
                cboAccount.SelectedIndex = index; // select the current user in the combo box
            }//try
            catch(Exception ex) 
            {
                txtOutput.Text = "ERROR!!\n" + ex.Message;
            }
        }

        // Utility Method(s)
        private void Display() //called from click and selection events to update the UI output for the current account
        {
            if (cboAccount.SelectedIndex != -1)
            {
                // Assign SelectedIndex of ComboBox to BankAccount field
                current = accounts[cboAccount.SelectedIndex];
                // Output BankName to Output Textbox
                txtOutput.Text = BankAccount.BankName + "\n\n";
                // Polymorphically call the ToString() method and add to output
                txtOutput.Text += current.ToString();
                // Output ClientName to Name textbox
                txtName.Text = current.ClientName;
                // Determine the specific BankAccount Type - then Type Cast to access specific Property(s)
                // Also, enable/disable Overdraft textbox
                txtOverDraft.IsEnabled = false;
                if(current is PremiumAccount) // start with the most specific class first
                {
                    txtOverDraft.IsEnabled = true;
                    // Unbox (type-cast) the general BankAccount type to the more specific PremiumAccount
                    PremiumAccount account = (PremiumAccount)current;
                    txtRateFee.Text = account.Fee.ToString("c2");
                    txtOverDraft.Text = account.OverDraft.ToString("c2");
                }
                else if(current is ChequingAccount)
                {
                    ChequingAccount account = (ChequingAccount)current;
                    txtRateFee.Text = account.Fee.ToString("c2");
                }
                else // current is SavingsAccount
                {
                    SavingsAccount account = (SavingsAccount)current;
                    txtRateFee.Text = account.Interest.ToString("p2");
                }
            }
        }
        private void DisplayAccounts() // Display accounts in combo box
        {
            //load names
            this.cboAccount.Items.Clear();
            foreach (BankAccount b in accounts)
                this.cboAccount.Items.Add(b.ClientName);
        }
        private void CreateAccounts(BankAccount[] array) // populate the field array with 12 sample bank accounts
        {
            array[0] = new SavingsAccount(1, 100M, "John Brown", 0.04M);
            array[1] = new ChequingAccount(2, 150M, "Max Pane", 10M);
            array[2] = new PremiumAccount(3, 1000M, "Eli Green", 10M, 100M);
            array[3] = new SavingsAccount(4, 1200M, "Rich Little", 0.05M);
            array[4] = new ChequingAccount(5, 150M, "Lara Croft", 10M);
            array[5] = new PremiumAccount(6, 1000M, "Commander Shepard", 10M, 100M);
            array[6] = new SavingsAccount(7, 100M, "V", 0.04M);
            array[7] = new ChequingAccount(8, 150M, "Maven Black-Briar", 10M);
            array[8] = new PremiumAccount(9, 1000M, "Mirabelle Ervine", 10M, 100M);
            array[9] = new SavingsAccount(10, 100M, "Arturo Rodriguez", 0.04M);
            array[10] = new ChequingAccount(11, 150M, "Nick Valentine", 10M);
            array[11] = new PremiumAccount(12, 1000M, "Piper Wright", 10M, 100M);
        }
    }//class
}//namespace
