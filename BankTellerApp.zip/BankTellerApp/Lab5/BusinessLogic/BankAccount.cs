﻿//PROG1224
//Lab 5 Start Files
// Umar Kamalitdinov

using System;

namespace Lab5.BusinessLogic
{
    //base class for all bank accounts
    public class BankAccount : Object
    {
        // private instance field
        private string name = "Unknown";
        private int accNumber;
        private readonly DateTime open;

        // protected instance field
        protected decimal balance;

        // public class field
        public const string BankName = "Bank Of OOP";

        // property for name field - read write
        public string ClientName
        {
            get => this.name;
            set
            {
                // check for empty string
                if (value.Length > 0)
                    this.name = value;
            }
        }

        // property for account number - read only
        public int AccountNumber
            => this.accNumber; 
        
        // property for opening date - read only - formatted as string
        public string DateOpen
            => open.ToLongDateString();
        
        // property for balance - read only - formatted as currency string
        public string Balance
            => balance.ToString("c2");

        // constructor
        public BankAccount(int accountNumber, decimal startBalance, string nameOfClient)
        {
            accNumber = accountNumber;
            balance = Math.Abs(startBalance);
            ClientName = nameOfClient;
            open = DateTime.Today;
        }

        // public methods
        public override string ToString()
            => $"Client Name: {this.name}\n" +
                $"Date Opened: {this.DateOpen}\n" +
                $"Account Number: {this.accNumber}\n" +
                $"Balance: {this.Balance}";
        
        public decimal Deposit(decimal amount)
        {
            if (amount > 0M)
            {
                this.balance += amount;
                return amount;
            }
            else
                return 0M;
        }

        // default Withdraw method
        public virtual decimal Withdraw(decimal amount)
        {
            if (amount > 0M && this.balance >= amount)
            {
                this.balance -= amount;
            }
            return amount;
        }     
    }
}
