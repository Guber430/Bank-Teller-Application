﻿//PROG1224
//Lab 5 Start Files
// Umar Kamalitdinov

using System;

namespace Lab5.BusinessLogic
{
    public sealed class PremiumAccount : ChequingAccount
    {
        // instance variable and property
        private decimal over = 100M;
        public decimal OverDraft
        {
            get => this.over;
            set
            {
                if (value >= 100M)
                    this.over = value;
            }
        }

        // constructor
        public PremiumAccount(int accountNumber, decimal startBalance, string nameOfClient, decimal fee, decimal over)
            : base(accountNumber, startBalance, nameOfClient, fee)
                => this.OverDraft = over;
        
        // methods
        public override decimal ApplyMonthlyFee()
        {
            decimal fee = base.ApplyMonthlyFee();
            this.balance -= 2M;
            return fee + 2M;
        }

        public override decimal Withdraw(decimal amount)
        {
            decimal additionalFee = 0M;
            if (amount > 0M && amount <= (base.balance + this.OverDraft))
            {
                base.balance -= amount;
                if(base.balance < 0M)
                {
                    additionalFee = Math.Abs(base.balance * 0.02M);
                    base.balance -= additionalFee;
                }
            }
            return amount + additionalFee;
        }
        public override string ToString()
        {
            return "Premium " + base.ToString() +
                $"\nOverdraft Amount: {over.ToString("C2")}";
        }
    }
}
