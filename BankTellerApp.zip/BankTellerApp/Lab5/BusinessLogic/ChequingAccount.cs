﻿//PROG1224
//Lab 5 Start Files
// Umar Kamalitdinov


namespace Lab5.BusinessLogic
{
    public class ChequingAccount : BankAccount
    {
        // instance variable and property
        private decimal fee = 10M;
        public decimal Fee
        {
            get => fee;
            set
            {
                if (value >= 10M)
                    fee = value;
            }
        }

        // constructor
        public ChequingAccount(int accountNumber, decimal startBalance, string nameOfClient, decimal fee)
            : base(accountNumber, startBalance, nameOfClient)
                => this.Fee = fee;
        

        // method
        public virtual decimal ApplyMonthlyFee()
        {
            this.balance -= this.fee;
            return this.fee;
        }
        public override string ToString()
        {
            return "Chequing Account\n" + base.ToString() +
                $"\nMonthly Fee: {fee.ToString("C2")}";
        }
    }
}
