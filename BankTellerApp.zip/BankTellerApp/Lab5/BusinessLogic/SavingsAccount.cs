﻿//PROG1224
//Lab 5 Start Files
// Umar Kamalitdinov

namespace Lab5.BusinessLogic
{
    public sealed class SavingsAccount : BankAccount
    {
        // instance variable and property
        private decimal interest = 0.04m;
        public decimal Interest
        {
            get => interest;
            set
            {
                // interest as a decimal value not percent
                if (value > 0.01m && value < 0.2m)
                    interest = value;
            }
        }

        // constructor
        public SavingsAccount(int accountNumber, decimal startBalance, string nameOfClient, decimal interest)
            : base(accountNumber, startBalance, nameOfClient)
                => Interest = interest;
        

        // methods
        public decimal ApplyMonthlyInterest()
        {
            decimal amountApplied = base.balance * this.interest;
            base.balance = base.balance + amountApplied;
            return amountApplied;
        }
        public override decimal Withdraw(decimal amount)
        {
            if (amount > 0M && amount <= (balance + 0.5M))
            {
                // each withdraw is charged 50 cents
                balance = balance - amount - 0.5M;
            }
            return amount + 0.5M;
        }
        public override string ToString()
        {
            return "Savings Account\n" + base.ToString() +
                $"\nInterest Rate: {interest.ToString("P2")}";
        }
    }
}
